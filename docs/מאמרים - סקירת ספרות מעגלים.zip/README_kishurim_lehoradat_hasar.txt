מקורות שלא נכללו ב-ZIP (חסומים להורדה מהסביבה שבה עבדתי) - קישורים ישירים להורדה:

בעברית:
1. בנבנישתי ופרידמן (2020) - דוח ועדת המומחים על למידה רגשית-חברתית:
   https://education.academy.ac.il/SystemFiles/22-9-20%20SEL%20all.pdf
2. גרומן וצוריאל (2022) + מזרחי ויריב (2022) - חוקרים@החינוך המיוחד, גיליון 2:
   https://www.l-w.ac.il/articles/researchers-special-education/gilyonot-special-education/special-education-issue-2/
3. הר-צבי, ממן-בכר וסאניצקי מולר (2023) - היקשים מילוליים:
   https://www.talpiot.ac.il/wp-content/uploads/2023/02/הר-צבי-שירלי.pdf
4. משרד החינוך (2009) - דוח ועדת דורנר: לחפש "דוח הוועדה הציבורית לבחינת מערכת החינוך המיוחד בישראל" באתר משרד החינוך

באנגלית (גישה חופשית):
5. Dale, Rispoli & Ruble (2022): https://digitalcommons.pace.edu/perspectives/vol6/iss2/12/
6. Dean et al. (2020): https://pmc.ncbi.nlm.nih.gov/articles/PMC7540922/
7. Hillman et al. (2020): https://onlinelibrary.wiley.com/doi/full/10.1002/cl2.1086
8. Pasqualotto et al. (2021): https://www.mdpi.com/2076-3425/11/10/1280
9. Zeidan et al. (2022): https://onlinelibrary.wiley.com/doi/full/10.1002/aur.2696

באנגלית (דרך ספריית המכללה - בתשלום):
10. Berard et al. (2017): https://doi.org/10.1177/0829573517707907
11. Hebron & Humphrey (2014): Journal of Research in Special Educational Needs, 14(1), 22-32
