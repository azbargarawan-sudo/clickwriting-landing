מצב המקורות (מעודכן):

נמצאים ב-ZIP: כל 11 המאמרים בעברית ששלחת, חוברת מעגלים, Durlak 2011, Dean 2020, Zeidan 2022.

נותר להוריד:
1. בנבנישתי ופרידמן (2020): https://education.academy.ac.il/SystemFiles/22-9-20%20SEL%20all.pdf
2. גרומן וצוריאל (2022) + מזרחי ויריב (2022) - גיליון 2 של חוקרים@החינוך המיוחד:
   https://www.l-w.ac.il/articles/researchers-special-education/gilyonot-special-education/special-education-issue-2/
3. הר-צבי ואחרים (2023): https://www.talpiot.ac.il/wp-content/uploads/2023/02/הר-צבי-שירלי.pdf
4. משרד החינוך (2009) - דוח דורנר: לחפש בגוגל "דוח הוועדה הציבורית לבחינת מערכת החינוך המיוחד בישראל PDF"
5. Dale et al. (2022): https://digitalcommons.pace.edu/perspectives/vol6/iss2/12/
6. Hillman et al. (2020): https://onlinelibrary.wiley.com/doi/full/10.1002/cl2.1086

8. Berard et al. (2017) - דרך ספריית המכללה: https://doi.org/10.1177/0829573517707907
9. Hebron & Humphrey (2014) - הקישור הנכון (הקודם היה שגוי):
   https://doi.org/10.1111/j.1471-3802.2012.01246.x
   או: https://nasenjournals.onlinelibrary.wiley.com/doi/10.1111/j.1471-3802.2012.01246.x

שים לב: הקובץ שהורדת בשם Research_in_Spec_Educ_Needs__2013__Williams הוא מאמר אחר
(Williams & Hennig על עיצוב אתרים) - לא להשתמש בו. הורד את Hebron & Humphrey מהקישור למעלה.
